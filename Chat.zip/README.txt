CASTIVIO PLAYER — ANDROID LAUNCHER ICON RESOURCES

This pack contains only launcher icon resources. It does not change app UI,
splash screen, TV banner, package name, or app label.

Copy the contents of:
  app/src/main/res/
into the matching:
  app/src/main/res/
folder in the Android project, replacing the existing files with the same names.

Included:
- mipmap-mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi:
  ic_launcher.png
  ic_launcher_round.png
  ic_launcher_foreground.png
  ic_launcher_background.png
- mipmap-anydpi-v26:
  ic_launcher.xml
  ic_launcher_round.xml

Manifest references already confirmed in the repository:
  android:icon="@mipmap/ic_launcher"
  android:roundIcon="@mipmap/ic_launcher_round"

Adaptive foreground:
- 108dp canvas, density-specific pixel sizes.
- Artwork inset to 66% of canvas to reduce clipping risk from launcher masks.
- Background is solid deep navy.

After copying, inspect the icon on Samsung and at least one circular/squircle mask.
